<?php

namespace WPPayForm\App\Http\Controllers;

use WPPayForm\Framework\Http\Controller as BaseController;

abstract class Controller extends BaseController
{
    //
}
