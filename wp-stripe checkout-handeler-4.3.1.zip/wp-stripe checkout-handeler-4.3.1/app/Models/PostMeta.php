<?php

namespace WPPayForm\App\Models;

/**
 * Order Items Model
 * @since 1.0.0
 */
class PostMeta extends Model
{
    protected $table = 'postmeta';
}
