<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8"/>
    <meta http-equiv="Imagetoolbar" content="No"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php esc_html_e('Preview Form', 'wp-payment-form') ?></title>
    <?php
    wp_head();
    ?>
    <style type="text/css">
        .wpf_preview_title {
            display: inline-block;
            font-weight: bold;
            color: black !important;
        }
        .wpf_preview_title ul {
            list-style: none;
        }

        .wpf_preview_title ul li{
            display: inline-block;
            padding: 5px 12px;
            margin: 0;
        }

        .wpf_preview_action {
            display: inline-block;
            background: #dedede;
            color: #545454;
            border-radius: 4px;
            padding: 0px 8px;
            margin: 5px 0px;
            height: 30px;
        }
        .wpf_preview_body {
            padding: 40px 0px 40px 0px;
            width: 100%;
            background-color: #dedede;
            min-height: 85vh;
        }
        .wpf_preview_header {
            top: 0px;
            left: 0;
            right: 0px;
            padding: 0px 20px 0px 0px;
            background-color: #ebedee;
            color: black;
            max-height: 60px;
            font-size: 18px;
        }

        .wpf_preview_footer {
            display: block;
            overflow: hidden;
            max-width: 800px;
            margin: 0 auto;
            padding: 30px 0px;
        }

        html.wpf_go_full {
            padding-top: 0;
        }
        .wpf_go_full body {
            background: white;
        }
        .wpf_go_full .wpf_preview_body {
            background: white;
        }
        .wpf_go_full .wpf_preview_body #wpf_preview_top {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0;
            background: #feffff;
            color: #596075;
            box-shadow: 0px 5px 5px 6px #e6e6e6;
        }

        .wpf_preview_container_action {
            margin: 10px;
        }
        .wpf_preview_container_action span {
            font-size:28px;
            color: #605858;
            cursor: pointer;
        }
        .wpf_hide {
            display: none;
        }
        .wpf_go_full .wpf_preview_footer {
            display: none;
        }

        @media only screen and (max-width: 522px) {
            .wpf_preview_footer {
                padding: 30px;
                font-size: 15px;
            }
            .wpf_preview_title {
                font-size: 15px;
            }
            .wpf_preview_action {
                font-size: 15px;
            }
        }
    </style>
</head>
<body>
<div id="wpf_preview_top">
    <div class="wpf_preview_header">
        <div class="wpf_preview_title">
            <ul>
                <li class="wpf_form_name">
                    <?php echo intval($form->ID) .' - '. esc_attr($form->post_title) . ' ( Preview )';  ?>
                </li>
                <li>
                    <a href="<?php echo admin_url('admin.php?page=wppayform.php#/edit-form/' . intval($form_id) . '/form-builder') ?>">Edit Fields</a>
                </li>
            </ul>
        </div>
        <div class="wpf_preview_action_block" style="float: right;display: flex;">
            <div class="wpf_preview_action">
                [wppayform id="<?php echo intval($form_id); ?>"]
            </div>
            <div class="wpf_preview_container_action">
                <span class=" wpf_hide wpf-preview-expand dashicons dashicons-editor-expand"></span>
                <span class="wpf-preview-contrast dashicons dashicons-editor-contract"></span>
            </div>
        </div>

    </div>
    <div class="wpf_preview_body">
        <div class="wpf_form_preview_wrapper">
            <?php echo do_shortcode('[wppayform id="' . intval($form_id) . '"]'); ?>
        </div>
    </div>
    <div class="wpf_preview_footer">
        <p>You are seeing preview version of Ever Green Brain.com. This form is only accessible for Admin users. Other users
            may not access this page. To use this for in a page please use the following shortcode: [wppayform
            id='<?php echo intval($form_id); ?>']</p>
    </div>
</div>
<?php
wp_footer();
?>

<script type="text/javascript">


    jQuery(document).ready(function ($) {
        var status = window.localStorage.getItem('wpf_full_screen_preview');
        if ( status == 'no') {
            jQuery('html').toggleClass('wpf_go_full');
            $('.wpf-preview-contrast').toggleClass("wpf_hide");
            $('.wpf-preview-expand').toggleClass("wpf_hide");
        }

        $('.wpf-preview-contrast').on('click', function () {
            jQuery('html').toggleClass('wpf_go_full');
            $(this).toggleClass("wpf_hide")
            $('.wpf-preview-expand').toggleClass("wpf_hide");
            window.localStorage.setItem('wpf_full_screen_preview', 'no');
        });

        $('.wpf-preview-expand').on('click', function () {
            jQuery('html').toggleClass('wpf_go_full');
            $(this).toggleClass("wpf_hide")
            $('.wpf-preview-contrast').toggleClass("wpf_hide");
            window.localStorage.setItem('wpf_full_screen_preview', 'yes');
        });
    });
</script>

</body>
</html>
