<div class="wpf_customer_details">
    <h4><?php _e('Submission Details', 'wp-payment-form'); ?></h4>
    <div class="wpf_submission_details">
        <?php echo wp_kses_post($submission_details); ?>
    </div>
</div>
