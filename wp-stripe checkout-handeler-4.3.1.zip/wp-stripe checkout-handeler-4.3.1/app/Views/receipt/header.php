<div class="wpf_submission_header">
    <div class="wpf_submission_message">
        <?php echo wp_kses_post($header_content); ?>
    </div>
</div>
