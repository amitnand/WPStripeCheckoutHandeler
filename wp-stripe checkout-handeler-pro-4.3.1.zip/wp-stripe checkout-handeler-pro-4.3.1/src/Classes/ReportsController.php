<?php

namespace WPPayFormPro\Classes;

use WPPayForm\App\Http\Controllers\Controller;
use WPPayFormPro\Models\Reports;
use WPPayFormPro\Models\Customers;


class ReportsController extends Controller
{

	public function getReports()
	{
        return (new Reports())->getReports();
	}

	public function getTodaysData()
	{
        return (new Reports())->getTodaysData();
	}

	public function getStatistics()
	{
		return (new Reports())->getStatistics();
	}

	public function getRecentRevenue()
	{
		return (new Reports())->getRecentRevenue();
	}

	public function topCustomers($request)
	{
		return (new Reports())->topCustomers($request);
	}

	public function customers($request)
	{
		return (new Customers())->index($request);
	}

	public function customer($customerEmail)
	{
		return (new Customers())->customer($customerEmail);
	}

	public function customerProfile($customerEmail)
	{
		return (new Customers())->customerProfile($customerEmail);
	}

	public function customerEngagements($customerEmail)
	{
		return (new Customers())->customerEngagements($customerEmail);
	}
}
