<?php
namespace WPPayFormPro\GateWays;

use WPPayForm\Framework\Support\Arr;

class PaymentController
{
    public function handleEndpoint($request, $payMethod)
    {
        $type = $request->method();
        $validRoutes = [
            'GET'  => 'getPaymentMethodSettings',
            'POST' => 'savePaymentMethodSettings',
        ];

        if (isset($validRoutes[$type])) {
            return $this->{$validRoutes[$type]}($request, $payMethod);
        }

        die();
    }

    public function verifyKeys($request, $payMethod)
    {
      $response = apply_filters('wppayform_verify_payment_keys_' . $payMethod, [], $request->all());
      return $response;
    }

    public function getAllPaymentSettingsRoute($request)
    {
        $settings = [
            'stripe' => [
                'title' => 'Stripe',
                'route_name' => 'stripe',
                'svg' => 'stripe.svg',
              ],
              'paypal' => [
                'title' => 'PayPal',
                'route_name' => 'paypal',
                'svg' => 'paypal.svg',
                'route_query' => [
                ],
              ],
              'mollie' => [
                'title' => 'Mollie',
                'route_name' => 'mollie',
                'svg' => 'mollie.svg',
                'route_query' => [
                ],
              ],
              'razorpay' => [
                'title' => 'Razorpay',
                'route_name' => 'razorpay',
                'route_query' => [
                ],
                'svg' => 'razorpay.svg',
              ],
              'paystack' => [
                'title' => 'Paystack',
                'route_name' => 'paystack',
                'route_query' => [
                ],
                'svg' => 'paystack.svg',
              ],
              'square' => [
                'title' => 'Square',
                'route_name' => 'square',
                'route_query' => [
                ],
                'svg' => 'square.svg',
              ],
              'payrexx' => [
                'title' => 'Payrexx',
                'route_name' => 'payrexx',
                'route_query' => [
                ],
                'svg' => 'payrexx.svg',
              ],
              'billplz' => [
                'title' => 'Billplz',
                'route_name' => 'billplz',
                'route_query' => [
                ],
                'svg' => 'billplz.svg',
              ],
              'sslcommerz' => [
                'title' => 'SSLCommerz',
                'route_name' => 'sslcommerz',
                'route_query' => [
                ],
                'svg' => 'sslcommerz.svg',
              ],
              'offline' => [
                'title' => 'Offline',
                'route_name' => 'offline',
                'route_query' => [
                ],
                'svg' => 'offline.svg',
              ],
        ];
        $settings = apply_filters('wppayform_payment_method_settings_route' , $settings);
        return $settings;
    }

    public function getPaymentMethodSettings($request, $payMethod)
    {
        $method = sanitize_text_field($payMethod);
        $settings = apply_filters('wppayform_payment_settings_' . $method, []);
        return $settings;
    }

    public function savePaymentMethodSettings($request, $method)
    {
        $settings = $request->settings;
        $settings = apply_filters('wppayform_payment_method_settings_mapper_' . $method, $settings);
        $validationErrors = apply_filters('wppayform_payment_method_settings_validation_' . $method, [], $settings);

        if ($validationErrors) {
            wp_send_json_error([
                'message' => __('Failed to save settings', 'wp-payment-form-pro'),
                'errors'  => $validationErrors
            ], 423);
        }

        $settings = apply_filters('wppayform_payment_method_settings_save_' . $method, $settings);

        update_option('wppayform_payment_settings_' . $method, $settings, 'yes');

        do_action('wppayform/before_save_payment_settings_' . $method, $settings);

        return array(
            'message' => __('Settings successfully updated', 'wp-payment-form-pro')
        );
    }
}
