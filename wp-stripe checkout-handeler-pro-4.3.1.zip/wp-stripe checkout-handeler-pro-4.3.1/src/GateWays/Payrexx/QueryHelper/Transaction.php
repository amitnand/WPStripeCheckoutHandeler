<?php
namespace WPPayFormPro\GateWays\Payrexx\QueryHelper;

class Transaction extends Base
{

    protected $referenceId;

    public function getReferenceId()
    {
        return $this->referenceId;
    }

    public function setReferenceId($referenceId)
    {
        $this->referenceId = $referenceId;
    }

    public function getResponseModel()
    {
        return new Transaction();
    }
}
