<?php

namespace WPPayFormPro\GateWays\Square;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

use WPPayForm\Framework\Support\Arr;
use WPPayFormPro\GateWays\Square\API\IPN;
use WPPayForm\App\Models\Transaction;
use WPPayForm\App\Models\Submission;
use WPPayForm\App\Models\Form;
use WPPayForm\App\Services\PlaceholderParser;
use WPPayForm\App\Services\ConfirmationHelper;

class SquareProcessor
{
    public $method = 'square';

    protected $form;

    public function init()
    {
        new SquareElement();
        (new SquareSettings())->init();

        add_filter('wppayform/choose_payment_method_for_submission', array($this, 'choosePaymentMethod'), 10, 4);
        add_action('wppayform/form_submission_make_payment_' . $this->method, array($this, 'makeFormPayment'), 10, 6);
        add_action('wppayform_payment_frameless_' . $this->method, array($this, 'handleSessionRedirectBack'));

        add_filter('wppayform/entry_transactions_' . $this->method, array($this, 'addTransactionUrl'), 10, 2);
        add_filter('wppayform/submitted_payment_items_' . $this->method, array($this, 'validateSubscription'), 10, 4);
    }

    public function choosePaymentMethod($paymentMethod, $elements, $formId, $form_data)
    {
        if ($paymentMethod) {
            // Already someone choose that it's their payment method
            return $paymentMethod;
        }
        // Now We have to analyze the elements and return our payment method
        foreach ($elements as $element) {
            if ((isset($element['type']) && $element['type'] == 'square_gateway_element')) {
                return 'square';
            }
        }
        return $paymentMethod;
    }

    public function makeFormPayment($transactionId, $submissionId, $form_data, $form, $hasSubscriptions)
    {
        $paymentMode = $this->getPaymentMode();
        $transactionModel = new Transaction();
        if ($transactionId) {
            $transactionModel->updateTransaction($transactionId, array(
                'payment_mode' => $paymentMode
            ));
        }
        $transaction = $transactionModel->getTransaction($transactionId);

        $submission = (new Submission())->getSubmission($submissionId);

        $this->handleRedirect($transaction, $submission, $form, $paymentMode);
    }

    public function redirectUrl($formId, $submission)
    {
        $confirmation = ConfirmationHelper::getFormConfirmation($formId, $submission);
        return $confirmation['customUrl'];
    }


    public function handleRedirect($transaction, $submission, $form, $methodSettings)
    {
        $keys = SquareSettings::getApiKeys($form->ID);

        $listener_url = add_query_arg(array(
            'wppayform_payment' => $submission->id,
            'payment_method' => $this->method,
            'submission_hash' => $submission->submission_hash
        ), home_url());

        $paymentArgs = array(
            "idempotency_key" => $submission->submission_hash,
            "order" => array (
              "order" => array(
                "location_id" => Arr::get($keys, "location_id"),
                "line_items" => [
                  [
                    "quantity" => '1',
                    "item_type" => "ITEM",
                    "metadata" => [
                        'form_id'       => 'Form Id ' . strval($form->ID) ,
                        'submission_id' => 'Submission Id ' . strval($submission->id)
                    ],
                    "name" => "first item",
                    "base_price_money" => [
                      "amount" => intval($transaction->payment_total),
                      "currency" => $transaction->currency
                    ]
                  ]
                ],
              )
            ),
            "redirect_url" => $listener_url
        );

        $paymentArgs = apply_filters('wppayform_square_payment_args', $paymentArgs, $submission, $transaction, $form);
        $paymentIntent = (new API())->makeApiCall('checkouts', $paymentArgs, $form->ID, 'POST');

        if (isset($paymentIntent['errors'])) {
            wp_send_json_error(array(
                'message' => __(Arr::get($paymentIntent['errors'][0], 'detail'), 'wp-payment-form-pro')
            ), 423);
        }

        if (is_wp_error($paymentIntent)) {
            do_action('wppayform_log_data', [
                'form_id' => $submission->form_id,
                'submission_id' => $submission->id,
                'type' => 'activity',
                'created_by' => 'Paymattic BOT',
                'title' => 'Square Payment Webhook Error',
                'content' => $paymentIntent->get_error_message()
            ]);

            wp_send_json_error(array(
                'message' => __($paymentIntent->get_error_message(), 'wp-payment-form-pro')
            ), 423);
        }

        do_action('wppayform_log_data', [
            'form_id' => $form->ID,
            'submission_id' => $submission->id,
            'type' => 'activity',
            'created_by' => 'Paymattic BOT',
            'title' => 'Square Payment Redirect',
            'content' => 'User redirect to Square for completing the payment'
        ]);

        wp_send_json_success([
            'message' => __('You are redirecting to squareup.com to complete the purchase. Please wait while you are redirecting....', 'wp-payment-form-pro'),
            'call_next_method' => 'normalRedirect',
            'redirect_url' => Arr::get($paymentIntent, 'checkout.checkout_page_url')
        ], 200);
    }

    protected function getPaymentMode($formId = false)
    {
        $isLive = SquareSettings::isLive($formId);
        if ($isLive) {
            return 'live';
        }
        return 'test';
    }

    public function handleSessionRedirectBack($data)
    {

        $submissionId = intval($data['wppayform_payment']);
        $payId = Arr::get($data, 'transactionId');

        $submission = (new Submission())->getSubmission($submissionId);
        $transaction = $this->getLastTransaction($submissionId);

        $payment = (new API())->makeApiCall('orders/'.$payId, [], $submission->form_id);
        $status = Arr::get($payment, 'order.state');

        $redirectUrl = $this->redirectUrl($submission->form_id, $submission);


        if (is_wp_error($payment)) {
            do_action('wppayform_log_data', [
                'form_id' => $submission->form_id,
                'submission_id' => $submission->id,
                'type' => 'info',
                'created_by' => 'PayForm Bot',
                'content' => $payment->get_error_message()
            ]);
        }


        if ($status == 'COMPLETED') {
            wp_redirect($redirectUrl);
        }

        $transaction = $this->getLastTransaction($submissionId);

        $this->handlePaid($submission, $transaction, $payment);
    }

    public function addTransactionUrl($transactions, $submissionId)
    {
        foreach ($transactions as $transaction) {
            $path = $transaction->payment_mode === 'test' ? 'https://squareupsandbox.com/' : 'https://squareup.com/';
            if ($transaction->charge_id) {
                $transaction->transaction_url =  $path . 'dashboard/sales/transactions/' . $transaction->charge_id;
            }
        }
        return $transactions;
    }

    public function getLastTransaction($submissionId)
    {
        $transactionModel = new Transaction();
        $transaction = $transactionModel->where('submission_id', $submissionId)
            ->first();
        return $transaction;
    }

    public function handlePaid($submission, $transaction, $vendorTransaction)
    {
        if (!$transaction || $transaction->payment_method != $this->method || $transaction->status === 'paid') {
            return;
        }

        do_action('wppayform/form_submission_activity_start', $transaction->form_id);

        $status = 'paid';
        $updateData = [
            'payment_note'     => maybe_serialize($vendorTransaction),
            'charge_id'        => sanitize_text_field(Arr::get($vendorTransaction, 'order.id')),
        ];

        $this->markAsPaid('paid', $updateData, $transaction);
    }

    public function markAsPaid($status, $updateData, $transaction)
    {
        $submissionModel = new Submission();
        $submissionData = array(
            'payment_status' => $status,
            'updated_at' => current_time('Y-m-d H:i:s')
        );

        $submissionModel->where('id', $transaction->submission_id)->update($submissionData);
        $submission = $submissionModel->getSubmission($transaction->submission_id);

        $transactionModel = new Transaction();
        $updateDate = array(
            'charge_id' => $updateData['charge_id'],
            'payment_note' => $updateData['payment_note'],
            'status' => $status,
            'updated_at' => current_time('Y-m-d H:i:s')
        );

        $transactionModel->where('id', $transaction->id)->update($updateDate);
        $transaction = $transactionModel->getTransaction($transaction->id);
        do_action('wppayform_log_data', [
            'form_id' => $transaction->form_id,
            'submission_id' => $transaction->submission_id,
            'type' => 'info',
            'created_by' => 'PayForm Bot',
            'content' => sprintf(__('Transaction Marked as paid and Square Transaction ID: %s', 'wp-payment-form-pro'), $updateDate['charge_id'])
        ]);

        do_action('wppayform/form_payment_success_square', $submission, $transaction, $transaction->form_id, $updateDate);
        do_action('wppayform/form_payment_success', $submission, $transaction, $transaction->form_id, $updateDate);
    }

    public function validateSubscription($paymentItems, $formattedElements, $form_data, $subscriptionItems)
    {
        wp_send_json_error(array(
            'message' => __('Square doesn\'t support subscriptions right now', 'wp-payment-form-pro'),
            'payment_error' => true
        ), 423);
    }
}
