<?php

namespace WPPayFormPro\Integrations\LifterLMS;

use WPPayForm\Framework\Support\Arr;

class AddToCourseAction
{
    public function Add($feed, $formData, $entry, $formId)
    {
        $settings = $feed['processedValues'];

        $customerEmail = Arr::get($formData, 'customer_email');

        if (!is_email($customerEmail)) {
            return;
        }

        $user  = get_user_by('email', $customerEmail);
        $userId = $user ? $user->ID : $user;

        $courseId = Arr::get($settings, 'course_id');

        if (!$courseId) {
            $message = __('Data Skipped because no course found', 'wp-payment-form-pro');
            do_action('wppayform_log_data', [
                'form_id' => $formId,
                'submission_id' => $entry->id,
                'type' => 'failed',
                'created_by' => 'Paymattic BOT',
                'content' => $message
            ]);
            return false;
        }

        if (!$userId) {
            $formData['user_id'] = '';
            // If no user found then let's create a user
            $welcomeEmail = Arr::get($settings, 'send_welcome_email') == 'yes';

            $userId = LifterLMSHelper::createWpUserFromSubscriber($formData, $entry->id, $welcomeEmail);

            if (is_wp_error($userId)) {
                //user not created
                return false;
            }
        }

        if (LifterLMSHelper::isInCourses([$courseId], $userId)) {
            $message = __('User already in the course-LifterLMS', 'wp-payment-form-pro');
            do_action('wppayform_log_data', [
                'form_id' => $formId,
                'submission_id' => $entry->id,
                'type' => 'failed',
                'created_by' => 'Paymattic BOT',
                'content' => $message
            ]);
            return false;
        }

        $result = llms_enroll_student($userId, $courseId);

        if (!$result) {
            $message = __('User could not be enrolled to the selected course', 'wp-payment-form-pro');
            do_action('wppayform_log_data', [
                'form_id' => $formId,
                'submission_id' => $entry->id,
                'type' => 'failed',
                'created_by' => 'Paymattic BOT',
                'content' => $message
            ]);
            return false;
        } else {
            $message = __('User enrolled to the selected course-LifterLMS', 'wp-payment-form-pro');
            do_action('wppayform_log_data', [
                'form_id' => $formId,
                'submission_id' => $entry->id,
                'type' => 'success',
                'created_by' => 'Paymattic BOT',
                'content' => $message
            ]);
        }
    }

}
