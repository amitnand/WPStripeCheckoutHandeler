<?php

namespace WPPayFormPro\Integrations\TutorLMS;

use WPPayForm\Framework\Support\Arr;
use WPPayForm\App\Services\ConditionAssesor;
use WPPayForm\App\Services\Integrations\IntegrationManager;
use WPPayForm\Framework\Foundation\App;
use WPPayFormPro\Integrations\TutorLMS\AddToCourseAction;

class Bootstrap extends IntegrationManager
{
    public $hasGlobalMenu = false;

    public $disableGlobalSettings = 'yes';

    public function __construct()
    {
        parent::__construct(
            App::getInstance(),
            'TutorLMS',
            'tutorlms',
            '_wppayform_tutorlms_settings',
            'tutorlms_feeds',
            10
        );

        $this->logo = WPPAYFORM_URL . 'assets/images/integrations/tutorlms.png';

        $this->description = __('Connect TutorLMS with Paymattic and subscribe a contact when a form is submitted.', 'wp-payment-form-pro');

        $this->registerAdminHooks();

        $this->category = 'lms';

        // this is required
        add_filter('wppayform_notifying_async_tutorlms', '__return_false');

        add_filter('wppayform_global_addons', array($this, 'addInstruction'));
    }

    public function addInstruction($addOns)
    {
        if (defined('TUTOR_VERSION')) {
            return $addOns;
        }

        $instruction = array(
            'tutorlms'   => array(
                'title'        => 'TutorLMS',
                'description'  => 'Connect TutorLMS with Paymattic and subscribe a contact when a form is submitted.',
                'logo'         =>  WPPAYFORM_URL . 'assets/images/integrations/tutorlms.png',
                'enabled'      => 'no',
                'purchase_url' => 'https://wordpress.org/plugins/tutor/',
                'category'     => $this->category,
                'btnTxt'       => 'Install & Activate'
            ),
        );
        return array_merge($addOns, $instruction);
    }

    public function pushIntegration($integrations, $formId)
    {
        $integrations[$this->integrationKey] = [
            'title' => $this->title . ' Integration',
            'logo' => $this->logo,
            'is_active' => $this->isConfigured(),
            'configure_title' => __('Configuration required!', 'wp-payment-form-pro'),
            'global_configure_url' => '#',
            'configure_message' => __('TutorLMS is not configured yet! Please configure your TutorLMS api first', 'wp-payment-form-pro'),
            'configure_button_text' => __('Set TutorLMS', 'wp-payment-form-pro')
        ];
        return $integrations;
    }

    public function getIntegrationDefaults($settings, $formId)
    {
        return [
            'name' => '',
            'email' => '',
            'course_id' => '',
            // 'skip_if_exists' => false,
            'send_welcome_email' => true,
            'remove_on_refund' => false,
            'trigger_on_payment' => false,
            'conditionals' => [
                'conditions' => [],
                'status' => false,
                'type' => 'all'
            ],
            'enabled' => true
        ];
    }

    public function getSettingsFields($settings, $formId)
    {

        return [
            'fields' => [
                [
                    'key' => 'name',
                    'label' => __('Feed Name', 'wp-payment-form-pro'),
                    'required' => true,
                    'placeholder' => __('Your Feed Name', 'wp-payment-form-pro'),
                    'component' => 'text'
                ],
                [
                    'key' => 'course_id',
                    'label' => __('TutorLMS Course', 'wp-payment-form-pro'),
                    'placeholder' => __('Select TutorLMS Course', 'wp-payment-form-pro'),
                    'tips' => __('Select the TutorLMS Course you would like enroll.', 'wp-payment-form-pro'),
                    'component' => 'select',
                    'required' => true,
                    'options' => $this->getCourses(),
                ],
                // [
                //     'key' => 'skip_if_exists',
                //     'require_list' => false,
                //     'checkbox_label' => __('Do not enroll the course if contact is not an existing WordPress User', 'wp-payment-form-pro'),
                //     'component' => 'checkbox-single'
                // ],
                [
                    'key' => 'send_welcome_email',
                    'require_list' => false,
                    'checkbox_label' => __('Send default WordPress Welcome Email for new WordPress users', 'wp-payment-form-pro'),
                    'component' => 'checkbox-single'
                ],
                [
                    'key' => 'remove_on_refund',
                    'require_list' => false,
                    'checkbox_label' => __('Remove user if refunded or subscription canceled', 'wp-payment-form-pro'),
                    'component' => 'checkbox-single'
                ],
                [
                    'key' => 'trigger_on_payment',
                    'require_list' => false,
                    'checkbox_label' => __('Enroll course on payment success only', 'wp-payment-form-pro'),
                    'component' => 'checkbox-single'
                ],
                [
                    'require_list' => false,
                    'key'          => 'conditionals',
                    'label'        => __('Conditional Logics', 'wp-payment-form-pro'),
                    'tips'         => __('Allow TutorLMS integration conditionally based on your submission values', 'wp-payment-form-pro'),
                    'component'    => 'conditional_block'
                ],
                [
                    'require_list' => false,
                    'key' => 'enabled',
                    'label' => 'Status',
                    'component' => 'checkbox-single',
                    'checkbox_label' => __('Enable This feed', 'wp-payment-form-pro')
                ]
            ],
            'button_require_list' => false,
            'integration_title' => $this->title
        ];
    }

    public function getMergeFields($list, $listId, $formId)
    {
        return [];
    }

    public static function getCourses()
    {
        $courses = get_posts(array(
            'post_type'   => 'courses',
            'numberposts' => -1
        ));
        $formattedLists = [];
        foreach ($courses as $list) {
            $formattedLists[$list->ID] = $list->post_title;
        }
        return $formattedLists;
    }

    /*
     * Form Submission Hooks Here
     */
    public function notify($feed, $formData, $entry, $formId)
    {
        return (new AddToCourseAction())->add($feed, $formData, $entry, $formId);
    }

    public function isConfigured()
    {
        return defined('TUTOR_VERSION');
    }

    public function isEnabled()
    {
        return true;
    }

    /*
     * We will remove this in future
     */
    protected function getSelectedTagIds($data, $inputData, $simpleKey = 'tag_ids', $routingId = 'tag_ids_selection_type', $routersKey = 'tag_routers')
    {
        $routing = Arr::get($data, $routingId, 'simple');
        if (!$routing || $routing == 'simple') {
            return Arr::get($data, $simpleKey, []);
        }

        $routers = Arr::get($data, $routersKey);
        if (empty($routers)) {
            return [];
        }

        return $this->evaluateRoutings($routers, $inputData);
    }

    /*
     * We will remove this in future
     */
    protected function evaluateRoutings($routings, $inputData)
    {
        $validInputs = [];
        foreach ($routings as $routing) {
            $inputValue = Arr::get($routing, 'input_value');
            if (!$inputValue) {
                continue;
            }
            $condition = [
                'conditionals' => [
                    'status' => true,
                    'is_test' => true,
                    'type' => 'any',
                    'conditions' => [
                        $routing
                    ]
                ]
            ];

            if (ConditionAssesor::evaluate($condition, $inputData)) {
                $validInputs[] = $inputValue;
            }
        }

        return $validInputs;
    }
}
