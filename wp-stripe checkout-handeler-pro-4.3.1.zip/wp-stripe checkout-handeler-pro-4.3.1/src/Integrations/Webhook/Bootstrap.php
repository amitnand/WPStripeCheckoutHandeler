<?php

namespace WPPayFormPro\Integrations\Webhook;

use WPPayForm\App\Services\GeneralSettings;
use WPPayForm\Framework\Foundation\App;
use WPPayForm\Framework\Support\Arr;

class Bootstrap
{
    public function __construct()
    {
        add_filter('wppayform_notifying_async_webhook', '__return_false');
        add_filter('wppayform_global_notification_active_types', function ($types) {
            $isEnabled = GeneralSettings::isModuleEnabled('webhook');
            if ($isEnabled) {
                $types['webhook'] = 'webhook';
            }
            return $types;
        });

        //This must be synchronous action, so don't comment this hook
        add_action('wppayform_integration_notify_webhook', array($this, 'notify'), 20, 4);
    }

    public function notify($feed, $formData, $entry, $formId)
    {
        $isEnabled = GeneralSettings::isModuleEnabled('webhook');
        if (!$isEnabled) {
            return;
        }
        $response = $this->getApiClient()->notify($feed, $formData, $entry, $formId);

        if (Arr::get($response, 'response.code') === 200) {
            do_action('wppayform_log_data', [
                'form_id' => $formId,
                'submission_id' => $entry->id,
                'type' => 'success',
                'created_by' => 'Paymattic BOT',
                'title' => 'Webhook',
                'content' => "Successfully Webhook payload has been fired."
            ]);
        } else {
            do_action('wppayform_log_data', [
                'form_id' => $formId,
                'submission_id' => $entry->id,
                'type' => 'failed',
                'created_by' => 'Paymattic BOT',
                'title' => 'Webhook',
                'content' => "Webhook feed failed (" . Arr::get($response, 'response.message') . ")"
            ]);
        }
    }

    protected function getApiClient()
    {
        return new Client();
    }
}
