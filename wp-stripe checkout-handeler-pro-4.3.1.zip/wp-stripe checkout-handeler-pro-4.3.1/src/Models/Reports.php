<?php

namespace WPPayFormPro\Models;

use WPPayForm\App\Models\Model;
use WPPayForm\App\Models\Form;
use WPPayForm\App\Models\Submission;
use WPPayForm\Framework\Support\Arr;
use WPPayForm\Framework\Foundation\App;
use WPPayForm\App\Services\GeneralSettings;


class Reports
{
    public function getReports()
    {
        $status = Form::getStatus();
        $stats = Arr::get($status, 'stats', []);
        $paidStats = Arr::get($status, 'paidStats', []);

        $customer = Submission::getByCustomerEmail();
        $customerProfiles = [];

        foreach ($customer as $value) {
            $email = $value['customer_email'];
            $customerProfiles[$email]['count'] = isset($customerProfiles[$email]['count']) ? $customerProfiles[$email]['count'] : 0;
            $customerProfiles[$email]['items'][] = array(
                "currency" => $value["currency"],
                "total_paid" => floatval($value["total_paid"]) / 100,
                "submissions" => $value["submissions"]
            );
            $customerProfiles[$email]['name'] = $value["customer_name"];
            $customerProfiles[$email]['count'] += intval($value['submissions']);
        }

        $chartData = array(
            'labels' => [],
            'data' => []
        );
        foreach($paidStats as $statusVal) {
            $chartData['label'][] = $statusVal['currency'];
            $chartData['data'][] = floatval($statusVal['total_paid'] / 100);
        }

        return array(
            'payments' => $stats,
            'customer' => $customerProfiles,
            'currency_base' => $paidStats,
            'chart' => $chartData,
            'entries_count' => Submission::count()
        );
    }

    public static function getTodaysData()
    {
        $now = current_time('mysql');
        $beforeAWeek = date('Y-m-d 00:00.01', strtotime($now) - 604800);
        $beforeTwoWeek = date('Y-m-d 00:00.01', strtotime($now) - 1209600);

        $customerNew = Submission::select(
            'customer_email',
            'created_at'
        )
            ->whereIn('payment_status', ['paid'])
            ->where('payment_total', '>', 0)
            ->groupBy('customer_email')
            ->where('created_at', '>', $beforeAWeek)
            ->get()->count();

        $customerNew2ndWeek = Submission::select(
            'customer_email',
            'created_at'
        )
            ->whereIn('payment_status', ['paid'])
            ->where('payment_total', '>', 0)
            ->groupBy(['customer_email'])
            ->whereBetween('created_at', [$beforeTwoWeek, $beforeAWeek])
            ->get()->count();

        $total = Submission::select(
            'customer_email',
            'created_at'
        )
            ->whereIn('payment_status', ['paid'])
            ->where('payment_total', '>', 0)
            ->groupBy('customer_email')
            ->get()->count();

        $totalBeforeWeek = $total - $customerNew;

        if ($total == $customerNew || $total == 0) {
            $increasedTotal = 100;
        } else {
            $increasedTotal = round(($customerNew * 100) / $totalBeforeWeek);

        }

        $newCustomerPercent = self::getDiff($customerNew2ndWeek, $customerNew);
        $chartNew = self::getChartData($newCustomerPercent);

        $DB = App::make('db');
        $paidStats = Submission::select(
            'form_id',
            'currency',
            $DB->raw("SUM(payment_total) as total_paid")
        )
            ->whereIn('payment_status', ['paid'])
            ->groupBy('currency')
            ->whereBetween('created_at', [$beforeAWeek, $now])
            ->get();

        $weeklyData = [];
        $weeklyLabel = [];

        $globalCurrency = GeneralSettings::getGlobalCurrencySettings();

        if ($paidStats->isEmpty()) {
            $paidStats = array(
                array(
                    "form_id" => "0",
                    "currency" => "USD",
                    "total_paid" => "0",
                    "formattedTotal" =>  '0 ' . Arr::get($globalCurrency, 'currency', 'USD')
                ),
            );
        } else {
            foreach ($paidStats as $paidStat) {
                $totalPaid = intval($paidStat->total_paid) / 100;
                $weeklyLabel[] = $paidStat->currency;
                $weeklyData[] = $totalPaid;
                $paidStat->formattedTotal = $totalPaid;
            }
        }

        //This query need to refactor,
        // now duplicate customer email is not checked
        $customersAll = Submission::select(
            'customer_email',
            'payment_status',
            $DB->raw('Date(created_at) as date'),
            $DB->raw("COUNT(customer_email) as count")
        )
            ->whereIn('payment_status', ['paid'])
            ->where('payment_total', '>', 0)
            ->groupBy([$DB->raw('Date(created_at)')])
            ->orderBy('id', 'desc')
            ->limit(10)
            ->get();

        $chartTotal  = array(
            'label' => [],
            'data' => []
        );

        foreach($customersAll as $customer) {
            $chartTotal['label'][] = $customer['date'];
            $chartTotal['data'][] = $customer['count'];
        }

        return array (
            'revenueWeekly' =>  array (
                'id' => 'revenue_overview',
                'title' => 'Revenue This Week',
                'type' => 'bar',
                'height' => '70',
                'value' => $paidStats,
                'change' => '',
                'label' => $weeklyLabel,
                'data' => $weeklyData,
                'color' => 'rgb(22,198,114)',
                'backgroundColor' => 'rgb(233,247,239)',
            ),
            'customersStats' => array(
                array(
                    'id'=> 'total_customers',
                    'title'=> 'Total Customers',
                    'type'=> 'line',
                    'height'=> '70',
                    'value'=> $total,
                    'change'=> $increasedTotal. '% of last week',
                    'label'=> $chartTotal['label'],
                    'data'=> $chartTotal['data'],
                    'color'=> 'rgb(255,184,36)',
                    'backgroundColor'=> 'rgb(254,245,232)',
                ),
                array(
                    'id'=> 'customer_new',
                    'title'=> 'New Customers',
                    'type'=> 'line',
                    'height'=> '70',
                    'value'=> $customerNew . '/week',
                    'change'=> $newCustomerPercent. '% of last week',
                    'label'=> $chartNew['label'],
                    'data'=> $chartNew['data'],
                    'color'=> 'rgb(192 161 232)',
                    'backgroundColor'=> 'rgb(233 220 250)',
                ),
            )
        );
    }

    public static function getChartData($rate)
    {
        $data = [];
        $label = [1, 2, 3, 4, 5, 6];
        foreach ($label as $value) {
            $val = intval($value * $rate);
            array_push($data, $val);
        }
        return array(
            'label' => $label,
            'data' => $data
        );
    }

    private static function getDiff($last, $new)
    {
        if ($last == 0) {
            return 100;
        } else if($new == 0) {
            return -100;
        } else {
            return round((($new - $last) / $last) * 100);
        }
    }

    public static function getColors($colorArray, $labels)
    {
        $colors = [];
        foreach ($labels as $status) {
            $lb = strtolower($status);
            $colors[] = isset($colorArray[$lb]) ? $colorArray[$lb] : '#ccc';
        }

        return $colors;
    }

    public function getStatistics()
    {
        $DB = App::make('db');
        $statuses = Submission::select(
            'form_id',
            'payment_status',
            $DB->raw("COUNT(payment_status) as count")
        )
            ->where('payment_method', '!=', '')
            ->groupBy('payment_status')
            ->get();

            $statusLabels = [];
            $statusData = [];
            // dd($statuses->toArray());
            foreach ($statuses as $status) {
                $statusLabels[] = $status['payment_status'];
                $statusData[] = intval($status['count']);
            }

        $methods = Submission::select(
            'form_id',
            'payment_method',
            $DB->raw("COUNT(payment_method) as count")
        )
            ->where('payment_method', '!=', '')
            ->groupBy('payment_method')
            ->get();

        $methodLabels = [];
        $methodData = [];
        foreach ($methods as $method) {
            $methodLabels[] = ucfirst($method['payment_method']);
            $methodData[] = intval($method['count']);
        }

        // status colors
        $statusColor = [
            'paid' => '#1DC373',
            'pending' => '#FED786',
            'refunded' => '#7f807f',
            'failed' => '#FF6E9B',
            'cancelled' => 'rgb(255,0,0)',
            'precessing' => '#077BFC',
            'waiting' => '#C85FFF',
        ];

        $statusColors = self::getColors($statusColor, $statusLabels);  // get colors

        $methodColors = [
            'stripe' => '#E4EDFB',
            'paypal' => '#E4F3EA',
            'mollie' => '#FBF2E5',
            'razorpay' => '#E7DBF8',
            'paystack' => '#CCFEFF',
            'square' => '#FFC2D8',
            'payrexx' => '#BAFFB3',
            'sslcommerz' => '#C7CFFF',
        ];

       $methodColors = self::getColors($methodColors, $methodLabels);  // get colors

        return array(
            'payment_statuses' => array(
                'height' => 330,
                'width' => 'auto',
                'id' => 'payment_status_chart',
                'type' => 'bar',
                'title' => 'Payment Status',
                'label' => $statusLabels,
                'data' => $statusData,
                'value' => $statuses,
                'color' => $statusColors,
                'backgroundColor' => $statusColors,
            ),
            'payment_methods' => array(
                'height' => '50',
                'width' => '50',
                'id' => 'method_chart',
                'type' => 'doughnut',
                'title' => 'Payment Status',
                'label' => $methodLabels,
                'color' => $methodColors,
                'backgroundColor' => $methodColors,
                'data' => $methodData,
                'value' => $methods,
            )
        );
    }

    public function topCustomers($request)
    {
        $customer = Submission::getByCustomerEmail();
        $customerProfiles = [];
        $filter = $request->currency;
        if ($filter === 'transactions') {
            $customerProfiles = $this->getCustomerProfiles($customer);
        } else {
            // filter by currency
            foreach ($customer as $value) {
                if ($value['currency'] === $filter) {
                    $email = $value['customer_email'];
                    $customerProfiles[$email]['count'] = isset($customerProfiles[$email]['count']) ? $customerProfiles[$email]['count'] : 0;
                    $customerProfiles[$email]['items'][] = array(
                        "currency" => $value["currency"],
                        "total_paid" => floatval($value["total_paid"]) / 100,
                        "submissions" => $value["submissions"]
                    );
                    $customerProfiles[$email]['name'] = $value["customer_name"];
                    $customerProfiles[$email]['count'] += intval($value['submissions']);
                }
            }

            //sorting top customers
            $customers = array();
            foreach ($customerProfiles as $email => $value) {
               $customers[$email] = $value['items'][0]['total_paid'];
            }
            array_multisort($customers, SORT_DESC, $customerProfiles);
        }

        return array(
            'customers' => $customerProfiles
        );
    }

    public function getCustomerProfiles($customer){
        $customerProfiles = [];
        foreach ($customer as $value) {
            $email = $value['customer_email'];
            $customerProfiles[$email]['count'] = isset($customerProfiles[$email]['count']) ? $customerProfiles[$email]['count'] : 0;
            $customerProfiles[$email]['items'][] = array(
                "currency" => $value["currency"],
                "total_paid" => floatval($value["total_paid"]) / 100,
                "submissions" => $value["submissions"]
            );
            $customerProfiles[$email]['name'] = $value["customer_name"];
            $customerProfiles[$email]['count'] += intval($value['submissions']);

        }
        return $customerProfiles;
    }

    public function getRecentRevenue($email = '')
    {
        $DB = App::make('db');
        $revenueQuery = Submission::select(
            'currency',
            'payment_status',
            $DB->raw('Date(created_at) as date'),
            $DB->raw("SUM(round(payment_total/ 100, 2)) as total_paid"),
            $DB->raw("COUNT(*) as submissions")
        );

        if ($email) {
            $revenueQuery->where('customer_email', $email);
        }

        $revenue = $revenueQuery->whereIn('payment_status', ['paid'])
            ->where('payment_total', '>', 0)
            ->groupBy([$DB->raw('Date(created_at)'), 'currency'])
            ->orderBy('id', 'desc')
            ->limit(50)
            ->get();


        $group = array();
        foreach ( $revenue as $value ) {
            $group[$value['currency']][] = $value;
        }

        $groupSelect = array();
        $chartData = array();
        foreach ($group as $key => $value) {
            $groupSelect[] = array(
                'label' => $key,
                'value' => $key,
            );
            foreach ($value as $val) {
                $chartData[$key]['label'][] = $val['date'];
                $chartData[$key]['data'][] = floatval($val['total_paid']);
            }
        }

        return array(
            'data' => $group,
            'options' => $groupSelect,
            'chartData' => $chartData,
        );
    }

}