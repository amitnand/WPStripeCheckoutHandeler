<?php

/**
 * Plugin Name: EverGreenBrain - WPStripeCheckoutHandelerPro
 * Plugin URI:  https://evergreenbrain.com/
 * Description: Create and Accept Payments in minutes with Stripe, PayPal with built-in form builder
 * Author: EverGreenBrain
 * Author URI:  https://evergreenbrain.com/
 * Version: 4.3.1
 * Text Domain: wp-stripe-checkout-handeler-pro
 * Domain Path: /language
 */

if (!defined('ABSPATH')) {
    exit;
}

defined('ABSPATH') or die;

define('WPPAYFORMPRO', true);
define('WPPAYFORMPRO_VERSION', '4.3.1');
define('WPPAYFORMPRO_UPLOAD_DIR', '/wppayform');
define('WPPAYFORMPRO_DIR_URL', plugin_dir_url(__FILE__));
define('WPPAYFORMPRO_DIR_PATH', plugin_dir_path(__FILE__));
define('WPPAYFORMPRO_DIR_FILE', __FILE__);

if (!defined('WPPAYFORMHASPRO')) {
    define('WPPAYFORMHASPRO', true);
}

include WPPAYFORMPRO_DIR_PATH . 'autoload.php';

if (!class_exists('WPPayFormPro')) {
    class WPPayFormPro
    {
        protected $addOns = array(
            'WPPayFormPro\Integrations\ActiveCampaign',
            'WPPayFormPro\Integrations\Zapier',
            'WPPayFormPro\Integrations\Webhook',
            'WPPayFormPro\Integrations\UserRegistration',
            'WPPayFormPro\Integrations\SMSNotification',
            'WPPayFormPro\Integrations\Telegram',
            'WPPayFormPro\Integrations\LearnDash',
            'WPPayFormPro\Integrations\LifterLMS',
            'WPPayFormPro\Integrations\TutorLMS',
            'WPPayFormPro\Integrations\GoogleSheet'
        );

        public function boot($app)
        {
            $this->commonHooks();
            $this->registerAddOns();
            $this->adminDependency($app);

            add_action('init', array($this, 'translate'));
        }

        public function translate() {
            load_plugin_textdomain('wp-payment-form-pro', false, dirname(plugin_basename(__FILE__)) . '/language');
        }

        public function adminDependency($app)
        {
            //pro version file init
            (new WPPayFormPro())->registerRoutes($app->router);

            add_filter('wppayform/form_entry', array("\WPPayFormPro\Classes\RecurringInfo", 'addRecurringSubscriptions'), 10, 1);
            add_action('wppayform/after_delete_submission', array("\WPPayFormPro\Classes\RecurringInfo", 'deleteSubscriptionData'), 99, 1);
            //payment method meta data
            add_filter('wpf_form_export_meta', function($formattedMeta, $formId) {
                $metaVal = WPPayForm\App\Models\Meta::getFormMeta($formId, '_payment_settings', []);
                $metas[] = array(
                    'wpf_meta_key'   => '_payment_settings',
                    'wpf_meta_value' => $metaVal
                );
                foreach ($metas as $meta) {
                    $formattedMeta[$meta['wpf_meta_key']] = maybe_unserialize($meta['wpf_meta_value']);
                }
                return $formattedMeta;
            }, 10, 2);
            // coupon actions
            $CouponController = new \WPPayFormPro\Classes\Coupons\CouponController();
            add_action('wp_ajax_wpf_coupon_apply', array($CouponController, 'validateCoupon'));
            add_action('wp_ajax_nopriv_wpf_coupon_apply', array($CouponController, 'validateCoupon'));
            add_action('wppayform/maybe_add_coupon_meta', array($CouponController, 'maybeAddCouponMeta'), 99,3);

            $licenseManager = new \WPPayFormPro\PluginManager\LicenseManager;
            $licenseManager->initUpdater();

            $licenseMessage = $licenseManager->getLicenseMessages();

            if ($licenseMessage) {
                add_action('admin_notices', function () use ($licenseMessage) {
                    $class = 'notice notice-error fc_message';
                    $message = $licenseMessage['message'];
                    printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), $message);
                });
            }

            // Handle Network new Site Activation
            add_action('wp_insert_site', function ($blogId) {
                switch_to_blog($blogId->blog_id);
                \WPPayForm\Database\DBMigrator::migrate();
                restore_current_blog();
            });
        }

        public function registerRoutes($router)
        {
            include WPPAYFORMPRO_DIR_PATH . 'src/Routes/api.php';
        }

        public function registerAddOns()
        {
            foreach ($this->addOns as $addOn) {
                $class = "{$addOn}\Bootstrap";
                new $class();
            }
        }

        public function commonHooks()
        {
            $scheduleSettings = new \WPPayFormPro\Classes\SchedulingSettings();
            $scheduleSettings->checkRestrictionHooks();

            $paymentHandler = new \WPPayFormPro\Classes\PaymentHandler();
            $paymentHandler->init();

            // Additional Form Info Handler
            $infoHandler = new \WPPayFormPro\Classes\FormAdditionalInfo();
            $infoHandler->register();

            $emailHandler = new \WPPayFormPro\Classes\EmailNotification\EmailHandler();
            $emailHandler->register();

            $userCreation = new \WPPayFormPro\Integrations\UserRegistration\UserCreation();
            $userCreation->register();

            // Init Pro Editor Components Here
            new \WPPayFormPro\Classes\Components\RecurringPaymentComponent();
            new \WPPayFormPro\Classes\Components\TaxItemComponent();
            new \WPPayFormPro\Classes\Components\TabularProductsComponent();
            new \WPPayFormPro\Classes\Components\FileUploadComponent();
            new \WPPayFormPro\Classes\Components\AddressFieldsComponent();
            new \WPPayFormPro\Classes\Components\MaskInputComponent();
            new \WPPayFormPro\Classes\Components\CouponComponent();
            new \WPPayFormPro\Classes\Components\DonationComponent();

            // Custom CSS and JS
            $customCssJS = new \WPPayFormPro\Classes\CustomScripts();
            $customCssJS->registerEndpoints();

            $LearnDashRemove = new \WPPayFormPro\Integrations\LearnDash\RemoveFromCourseAction();
            $LearnDashRemove->init();

            $LifterLMSRemove = new \WPPayFormPro\Integrations\LifterLMS\RemoveFromCourseAction();
            $LifterLMSRemove->init();

            $TutorLMSRemove = new \WPPayFormPro\Integrations\TutorLMS\RemoveFromCourseAction();
            $TutorLMSRemove->init();

            // Default value Parser
            $formDefaultValueRenderer = new \WPPayFormPro\Classes\DefaultValueParser\FormDefaultValueRenderer();
            $formDefaultValueRenderer->register();

            add_shortcode('payform_user_submissions', function ($args) {
                $handler = new \WPPayFormPro\Classes\ProShortCodeHandler();
                return $handler->handleUserSubmissionShortCode($args);
            });
        }
    }

    add_action('admin_init', function () {
        if (!defined('WPPAYFORM_VERSION_LITE')) {
            (new \WPPayFormPro\Classes\DependencyHandler\DependencyHandler())->injectProDependency();
        }
    });

    /**
     * Add dependency menu when free version not installed
     */
    add_action('admin_menu', function () {
        if (!defined('WPPAYFORM_VERSION_LITE')) {
            (new \WPPayFormPro\Classes\DependencyHandler\DependencyHandler())->add();
        }
    });


    add_action('wppayform_loaded', function ($app) {
        (new WPPayFormPro)->boot($app);
    });
}
